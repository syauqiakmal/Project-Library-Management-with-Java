package LibraryManagement;

public class Book {
	private String title;
	private String publisher;
	private int year;
	private String status;
	
	Book(String title, String publisher, int year){
		this.title = title;
		this.publisher = publisher;
		this.year = year;
		this.status = "Available";
		// by default available 
	}
	
	// getter
	public String getTitle() {
		return this.title;
	}
	public String getPublisher() {
		return this.publisher;
	}
	public String getStatus() {
		return this.status;
	}
	public int getYear() {
		return this.year;
	}

	// setter
	
	public void setTitle(String title) {
		this.title = title;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void year(int year) {
		this.year = year;
	}
	
	public String toString() {
		return String.format("%-20s|%-20s|%-20d|%-20s|\n",this.title, this.publisher, this.year, this.status);
	}
}
