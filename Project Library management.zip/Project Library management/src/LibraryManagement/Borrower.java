package LibraryManagement;

public class Borrower extends Person {
	
	private String role;
	
	Borrower(String name, String email, String noHp){
		super(name, email, noHp);
		this.role = "Peminjam";
	}
	
	//getter
	public String getRole() {
		return this.role;
	}
	//setter
	public void setRole(String role) {
		this.role = role;
	}
	
	public String getShift() {
		return null;
	}
	
	public String toString() {
		return super.toString() + String.format("%-20s|\n",this.role);
	}
}
