package LibraryManagement;

public class Employee extends Person{
	private String shift;
	private String role;
	
	Employee(String name, String noHp, String email, String shift){
		super(name, noHp,email);
		this.role = "Petugas";// default role
		this.shift = shift;
	}
	
	// getter
	public String getRole() {
		return this.role;
	}
	public String getShift() {
		return this.shift;
	}
	
	// setter
	
	public void setShift(String shift) {
		this.shift = shift;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	public String toString() {
		return super.toString() + String.format("%-20s|%-20s|\n",this.role, this.shift);	
	}

}
