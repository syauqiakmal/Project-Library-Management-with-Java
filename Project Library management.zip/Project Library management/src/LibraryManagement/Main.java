package LibraryManagement;


import java.util.*;
import java.io.*;
import java.lang.*;


	public class Main {
		static void MENU() {
			System.out.println();
			System.out.println("* * * T T T T T T T T T T T T T T T T T T * * *");
			System.out.println("========= LIBRARY MANAGEMENT SYSTEM ===========");
			
		
			System.out.println("1. Display");
			System.out.println("2. Input Data");
			System.out.println("3. Update Data");
			System.out.println("4. Delete Data");
			System.out.println("0. Exit");
			System.out.print(">> ");
		}
		
		static void view(List<TransactionDetail> details, List<Book> books, List<Person> persons, List<TransactionHistory> histories) {
			int ch;
			
			Scanner i = new Scanner(System.in);
			System.out.println("----- VIEW COMPONENT ------");
			System.out.println("1. View Data History");
			System.out.println("2. View Data Petugas");
			System.out.println("3. View Data Buku");
			System.out.println("4. View Data TransactionsDetails");
			System.out.println("5. Back");
			System.out.println(">> ");
			
			ch = i.nextInt();
			if(ch == 1) {
				viewTransactionHistory(histories);
			}
			if(ch == 2) {
				viewPetugas(persons);
			}
			if(ch == 3) {
				viewBook(books);
			}
			if(ch == 4) {
				viewTransactionsDetails(details);
			}
			if(ch == 5) {
				return;
			}
		}
		
		static void viewTransactionHistory(List<TransactionHistory> histories){
			System.out.println("============================================================================================================================");
			System.out.printf("%-20s|%-20s|%-20s|%-30s|%-30s|\n","Peminjam","Petugas","Buku","Tanggal Peminjaman","Tanggal Pengembalian");
			System.out.println("============================================================================================================================");
			Iterator<TransactionHistory> it = histories.iterator();
			while(it.hasNext()) {
				TransactionHistory h = it.next();
				System.out.println(h);
			}
		}
		
		static void viewPetugas(List<Person> persons){
			System.out.println("============================================================================================================");
			System.out.printf("%-20s|%-20s|%-20s|%-20s|%-20s\n","Name","Email","Phone","Role","Shift");
			System.out.println("============================================================================================================");
			Iterator<Person> it = persons.iterator();
			while(it.hasNext()) {
				Person p = it.next();
				if(p.getRole().equals("Petugas")) {
					System.out.println(p);	
				}
			}
		}
		
		static String searchPetugas(List<Person> persons, String day) {
			Iterator<Person> it = persons.iterator();
			String name = null;
			while(it.hasNext()) {
				Person p = it.next();
				if(p.getRole().equals("Petugas") && p.getShift().equals(day)) {
					name =  p.getName();
				}
			}
			return name;
		}
		
		static void viewTransactionsDetails(List<TransactionDetail> details) {
			System.out.println("=======================================================================================================================");
			System.out.printf("%-20s|%-20s|%-20s|%-20s|%-20s|\n","Peminjam","Petugas","Buku","Hari Peminjaman","Tanggal Peminjaman");
			System.out.println("=======================================================================================================================");
			Iterator<TransactionDetail> it = details.iterator();
			while(it.hasNext()) {
				TransactionDetail dt = it.next();
				System.out.println(dt);
			}
			
		}
		
		
		static void viewBook(List<Book> books){
			System.out.println("=========================================================================================");
			System.out.printf("%-20s|%-20s|%-20s|%-20s|\n","Judul","Penerbit","Tahun Terbit","Status");
			System.out.println("=========================================================================================");
			Iterator<Book> it = books.iterator();
			while(it.hasNext()) {
				Book b = it.next();
				System.out.println(b);
			}
		}
		
		static boolean checkAvailableBook(List<Book> books, String bookTitle) {
			Iterator<Book> it = books.iterator();
			while(it.hasNext()) {
				Book b = it.next();
				if(b.getStatus().equals("Available") && b.getTitle().equals(bookTitle)) {
					b.setStatus("Not Available");
					return true;
				}
			}
			return false;
		}
		
		static boolean updateAvailableBook(List<Book> books, String bookTitle) {
			Iterator<Book> it = books.iterator();
			while(it.hasNext()) {
				Book b = it.next();
				if(b.getStatus().equals("Not Available") && b.getTitle().equals(bookTitle)) {
					b.setStatus("Available");
					return true;
				}
			}
			return false;
		}
		
		static void input(List<TransactionDetail>details, List<Person>persons, List<Book> books) {
			String name;
			String email;
			String noHp;
			String bookTitle;
			
			String[] nameday = {"Senin", "Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu"};
			
			String day;
			String date;
			boolean checker;
			Scanner s = new Scanner(System.in);
			do {
				System.out.print("Input Your Name [Must consist at least 1 word] : ");
				name = s.nextLine();
			}while(name.length() < 1);
			
			do {
				System.out.print("Input Your Name [Must consist @email.com] : ");
				email = s.nextLine();
			}while(email.endsWith("@email.com") != true || email.length() < 5);
			
			do {
				System.out.print("Input Your Phone Number [Must start with 08] : ");
				noHp = s.nextLine();
			}while(noHp.startsWith("08")  != true || noHp.length() < 6);
			
			do {
				viewBook(books);
				System.out.print("Input Book Title You Want to Borrow : ");
				bookTitle = s.nextLine();
				checker = checkAvailableBook(books, bookTitle);
				if(checker == false) {
					System.out.println("Sorry, the book that you want to borrow might be 'Not Available'! ");
				}
			}while(checker == false);
			do {
				System.out.print("Input The Loan Day [hari peminjaman] : ");
				day = s.nextLine();
				checker = false;
				for(String d : nameday) {
					if(d.equals(day)) {
						checker = true;
					}
				}
				if(!checker) {
					System.out.println("Wrong Input Data of Day [Senin - Minggu]!");
				}
			}while(checker == false);
			
			do {
				checker = true;
				System.out.print("Input The Loan Date [DD-MM-YYYY] : ");
				date = s.nextLine();
				int d = Integer.parseInt(date.substring(0, 2));// validate day no more than 31
				int m = Integer.parseInt(date.substring(3, 5));// validate month no more than 12
				
				if(d > 31 || m > 12 || date.charAt(2) != '-' || date.charAt(5) != '-') {
					System.out.println("You must have input wrong date format[DD-MM-YYYY]!");
					checker = false;
				}
				
			}while(checker == false);
			String petugas = searchPetugas(persons, day);
			
			persons.add(new Borrower(name, noHp, email));
			details.add(new TransactionDetail(name ,petugas ,bookTitle ,day ,date));
			
			System.out.println("Data Have Succesfully Added!");
		}
		
		static boolean checkStaff(List<Person> persons, String username, String password) {
			Iterator<Person> it = persons.iterator();
			while(it.hasNext()) {
				Person p = it.next();
				if(p.getRole().equals("Petugas") && p.getName().equals(username) && p.getEmail().equals(password)) {
					System.out.println("--------------------------------------------");
					System.out.println("Welcome");
					System.out.println("Hi, " + p.getName());
					return true;
				}
			}
			return false;
		}
		
		
		static boolean checkLoan(List<TransactionDetail> details, String name, List<TransactionHistory> histories, String dateReturn, List<Book> books) {
			Iterator<TransactionDetail> it = details.iterator();
			while(it.hasNext()) {
				TransactionDetail p = it.next();
				if(p.getBorrower().equals(name)) {
					System.out.println(p);
					updateAvailableBook(books, p.getBookTitle());
					histories.add(new TransactionHistory(p.getBorrower(), p.getEmployee(), p.getBookTitle(), p.getDateBorrow(), dateReturn));
					// insert into history
					// delete from transaction detail
					it.remove();
					return true;
				}
			}
			return false;
		}
		
		static boolean checkPeminjam(List<TransactionDetail> details, String name) {
			Iterator<TransactionDetail> it = details.iterator();
			while(it.hasNext()) {
				TransactionDetail p = it.next();
				if(p.getBorrower().equals(name)) {
					System.out.println(p);
					return true;
				}
			}
			return false;
		}
		
		
		
		static void update(List<Person> persons, List<TransactionDetail> details, List<TransactionHistory> histories, List<Book> books) {
			String username;
			String password;
			String name;
			String date;
			
			boolean checker;
			Scanner s = new Scanner(System.in);
			do {
				checker = true;
				System.out.println("--> Login Area Staff Only <--");
				System.out.print("Input Your Username [Nama staff] : ");
				username = s.nextLine();
				System.out.print("Input Your Password [Email Staff] : ");
				password = s.nextLine();
				checker = checkStaff(persons, username, password);
				if(checker == false) {
					System.out.println("You must have input Wrong Username or Password ! ");
				}
			}while(checker == false);
			
			do {
				checker = true;
				System.out.println("^^Book Return Arrangements^^");
				viewTransactionsDetails(details);
				System.out.print("Input The Name of Borrower : ");
				name = s.nextLine();
				checker = checkPeminjam(details, name);
				if(checker == false) {
					System.out.println("Sorry, data was not found! ");
				}else {
					do {
						checker = true;
						System.out.print("Returned on Date[DD-MM-YYYY]: ");
						date = s.nextLine();
				
						int d = Integer.parseInt(date.substring(0, 2));// validate day no more than 31
						int m = Integer.parseInt(date.substring(3, 5));// validate month no more than 12
						
						if(d > 31 || m > 12 || date.charAt(2) != '-' || date.charAt(5) != '-') {
							checker = false;
							System.out.println("Wrong Date Input!");
						}else {
							checkLoan(details, name, histories,date, books);
							System.out.println(name + " has been removed from transaction details !");
						}
					}while(!checker);
				}
			}while(!checker);
			
		}
		
		static void delete(List<TransactionHistory> histories) {
			char validate;
			Scanner s = new Scanner(System.in);
			do {
				System.out.print("Do you really want to remove all data history [Y | N]: ");
				validate = s.next().charAt(0);
				s.nextLine();
			}while(validate != 'Y' && validate != 'N');
			if(validate == 'N') {
				return;
			}else {
				Iterator<TransactionHistory> th = histories.iterator();
				while(th.hasNext()) {
					if(histories.contains(th.next())) {
						th.remove();
					}
				}
				System.out.println("Data History Has Been Removed ALL ! ");
			}
		}
		
		public static void main(String[] args) {
			List<Person> persons = new ArrayList<Person>();
			List<Book> books = new ArrayList<Book>();
			List<TransactionDetail> details = new ArrayList<TransactionDetail>();
			List<TransactionHistory> histories = new ArrayList<TransactionHistory>();
			
			// dummy data for book
			books.add(new Book("Ekonomi XI", "Janeth Harista", 2007));
			books.add(new Book("IPA XII", "Ken Gajo", 2000));
			books.add(new Book("MATEMATIKA X", "Wincent Kie", 2013));
			books.add(new Book("MANDARIN IV", "Nick Son", 2021));
			books.add(new Book("INGGRIS VII", "Samuel Todai", 2005));
			
			/// dummy data for petugas
			persons.add(new Employee("Petugas 1", "@email.com", "0812121", "Senin"));
			persons.add(new Employee("Petugas 2", "@email.com", "0812121", "Selasa"));
			persons.add(new Employee("Petugas 3", "@email.com", "0812121", "Rabu"));
			persons.add(new Employee("Petugas 4", "@email.com", "0812121", "Kamis"));
			persons.add(new Employee("Petugas 5", "@email.com", "0812121", "Jumat"));
			persons.add(new Employee("Petugas 6", "@email.com", "0812121", "Sabtu"));
			persons.add(new Employee("Petugas 7", "@email.com", "0812121", "Minggu"));
				
			// dummy data for history
			histories.add(new TransactionHistory("Peminjam 5","Petugas 1 ","INGGRIS VII","12-05-2003","16-08-2003"));
			histories.add(new TransactionHistory("Peminjam 6","Petugas 2 ","MANDARIN IV","15-05-2004","16-08-2004"));
			histories.add(new TransactionHistory("Peminjam 7","Petugas 1 ","INGGRIS VII","13-03-2005","16-08-2005"));
			histories.add(new TransactionHistory("Peminjam 8","Petugas 4 ","MATEMATIKA X","14-02-2005","16-02-2005"));
			
			

			int ch;
			
			Scanner i = new Scanner(System.in);
			do {
				MENU();
				ch = i.nextInt();i.nextLine();
				do {
					switch(ch) {
					case 1: // show data
						view(details, books, persons, histories );
						break;
					case 2: // Input data
						input(details, persons,books);
						break;
					case 3:// update 
						update(persons, details, histories, books);
						break;
					case 4:
						delete(histories);
						break;
					}
				
				}while(ch < 0 || ch > 4);
			}while(ch != 0);
			
		}
}
