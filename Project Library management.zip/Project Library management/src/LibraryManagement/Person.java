package LibraryManagement;

import java.util.Iterator;

public abstract class Person {
	
	private String name;
	private String noHp;
	private String email;
	
	
	Person(String name, String email, String noHp){
		this.name = name;
		this.email = email;
		this.noHp = noHp;
	}
	
	// getter
	
	public String getName() {
		return this.name;
	}
	public String getNoHp() {
		return this.noHp;
	}
	public String getEmail(){
		return this.email;
	}

	// setter
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setNoHp(String noHp) {
		this.noHp = noHp;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public abstract String getRole();
	public abstract String getShift();

	
	public String toString() {
		return String.format("%-20s|%-20s|%-20s|",this.name, this.email, this.noHp);
	}


}
