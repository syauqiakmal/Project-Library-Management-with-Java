package LibraryManagement;

public class TransactionDetail {
	String dayBorrow;
	String dateBorrow;
	String borrower;
	String employee;
	String bookTitle;
	
	TransactionDetail(String borrower, String employee, String bookTitle, String dayBorrow, String dateBorrow){
		this.borrower = borrower;
		this.employee = employee;
		this.bookTitle = bookTitle;
		this.dayBorrow = dayBorrow;
		this.dateBorrow = dateBorrow;
	}
	
	// getter
	public String getBorrower() {
		return this.borrower;
	}
	public String getEmployee() {
		return this.employee;
	}
	public String getDayBorrow() {
		return this.dayBorrow;
	}
	public String getDateBorrow() {
		return this.dateBorrow;
	}
	public String getBookTitle() {
		return this.bookTitle;
	}
	// setter
	public void setBorrower(String name) {
		this.borrower = name;
	}
	public void setEmployee(String name) {
		this.employee = name;
	}
	public void setDayBorrow(String day) {
		this.dayBorrow = day;
	}
	public void setDateBorrow(String date) {
		this.dateBorrow = date;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	
	public String toString() {
		return String.format("%-20s|%-20s|%-20s|%-20s|%-20s|\n",this.borrower,this.employee,this.bookTitle, this.dayBorrow,this.dateBorrow);
	}
}
