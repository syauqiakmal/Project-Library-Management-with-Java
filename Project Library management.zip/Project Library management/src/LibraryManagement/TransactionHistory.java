package LibraryManagement;

public class TransactionHistory {
	private String peminjam;
	private String petugas;
	private String dateBorrow;
	private String dateReturn;
	private String bookTitle;
	
	TransactionHistory(String peminjam, String petugas, String bookTitle, String dateBorrow, String dateReturn){
		this.peminjam = peminjam;
		this.petugas = petugas;
		this.dateBorrow = dateBorrow;
		this.dateReturn = dateReturn;
		this.bookTitle = bookTitle;
	}
	
	// getter
	public String getPeminjam() {
		return this.peminjam;
	}
	public String getPetugas() {
		return this.petugas;
	}
	public String getDateBorrow() {
		return this.dateBorrow;
	}
	public String getDateReturn() {
		return this.dateReturn;
	}
	public String getBookTitle() {
		return this.bookTitle;
	}
	// setter
	public void setPeminjam(String name) {
		this.peminjam = name;
	}
	public void setPetugas(String name) {
		this.petugas = name;
	}
	public void setDateReturn(String date) {
		this.dateReturn = date;
	}
	public void setDateBorrow(String date) {
		this.dateBorrow = date;
	}
	public void setBookTitle(String title) {
		this.bookTitle = title;
	}
	
	public String toString() {
		return String.format("%-20s|%-20s|%-20s|%-30s|%-30s|\n",this.peminjam,this.petugas,this.bookTitle, this.dateBorrow,this.dateReturn);
	}
}
