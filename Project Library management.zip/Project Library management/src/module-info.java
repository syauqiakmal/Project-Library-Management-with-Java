/**
 * 
 */
/**
 * @author syauqi akmal deffans
 *
 */
module library1 {
}